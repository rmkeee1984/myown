﻿# PowerShell script for setting up a delegated DNS zone.
# Required script inputs:
#   ZoneName: The name of the DNS domain where the delegation will occur.
#   ChildZoneName: The name of the host/sub-domain to delegate.
#   IPAddress: CSV list of delegated nameserver IP addresses.
#
param($ZoneName, $ChildZoneName, $IPAddress)
if (! $ZoneName -Or ! $ChildZoneName -Or ! $IPAddress)
{
  throw "Required input parameters missing - aborting!"
}

$Delegate = $ChildZoneName + '.' + $ZoneName
$ip = $IPAddress.split(',')

# Check to see if there is an existing delegation for this child zone.
try {$zonedg = Get-DnsServerZoneDelegation -ZoneName $ZoneName -ChildZoneName $ChildZoneName}
catch {}
if ($zonedg) 
{
  write-output "Updating existing zone delegation for $Delegate"
  try {
    Set-DnsServerZoneDelegation -Name $ZoneName -ChildZoneName $ChildZoneName -NameServer $Delegate -IPAddress $ip -Verbose
  } catch { throw $_ }
}
else
{
  write-output  "Adding new zone delegation for $Delegate"
  try {
    Add-DnsServerZoneDelegation -Name $ZoneName -ChildZoneName $ChildZoneName -NameServer $Delegate -IPAddress $ip  -Verbose
  } catch { throw $_ }
}
