# ontap

Playbooks and other content for the Ansible with ONTAP lab.
